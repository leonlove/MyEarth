---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

<!-- Only file bugs here! Ask questions on the mailing lists https://curl.se/mail/

     SECURITY RELATED? Post it here: https://hackerone.com/curl

     There are collections of known issues to be aware of:
     https://curl.se/docs/knownbugs.html
     https://curl.se/docs/todo.html       -->

### I did this

### I expected the following

### curl/libcurl version

[curl -V output]

### operating system

<!-- On Unix please post the output of "uname -a" -->
