# Security Policy

See [docs/SECURITY-PROCESS.md](docs/SECURITY-PROCESS.md) for full details.

## Reporting a Vulnerability

If you have found or just suspect a security problem somewhere in curl or libcurl,
report it on [https://hackerone.com/curl](https://hackerone.com/curl).

We treat security issues with confidentiality until controlled and disclosed responsibly.
